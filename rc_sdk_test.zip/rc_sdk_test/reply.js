const respmap = {
    "hi" : "hey",
    "u da bot" : "no, YOU da bot",
    "no u da bot" : "Come'on - YOU DA BOT!!",
    "I give up" : "ok. silly human :rolleyes:"
};

module.exports = respmap;